
# Credit Card Default Prediction 🧾💳

This project uses logistic regression to predict whether a customer is likely to default on their credit card payment.

## 🧠 Features Used
- Income
- Age
- Loan
- Loan to Income Ratio (engineered)
- Default (target variable)

## 📦 Libraries Used
- pandas
- scikit-learn

## 📊 Model Used
- Logistic Regression

## 📈 Evaluation
- Accuracy Score
- Confusion Matrix
- Classification Report

## 🚀 How to Run
```bash
pip install -r requirements.txt
jupyter notebook Credit_Card_Default_Prediction.ipynb
```

## 📁 Dataset
- [Credit Default CSV](https://github.com/ybifoundation/Dataset/raw/main/Credit%20Default.csv)

## ✨ Author
- Forked from [YBI Foundation](https://www.ybifoundation.org/)
